print("Please give me your name")
name = input()

print("Please give me your age")
age = int(input())

print("Your name: {0}, age: {1}".format(name, age))
print("Next year you will be {0} years old".format(age + 1))
